using DIKUArcade.Entities;


namespace Galaga.MovementStrategy;

public class Down : IMovementStrategy
{
    public void MoveEnemies(EntityContainer<Enemy> enemies){
        enemies.CountEntities();
        enemies.RenderEntities();
       
    }

    public void MoveEnemy(Enemy enemy)
    {
        enemy.Shape.Position.Y -= enemy.Speed;
    }
}