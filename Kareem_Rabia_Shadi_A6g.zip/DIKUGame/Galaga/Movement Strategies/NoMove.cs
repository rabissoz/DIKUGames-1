using DIKUArcade.Entities;


namespace Galaga.MovementStrategy;

public class NoMove : IMovementStrategy
{
    public void MoveEnemies(EntityContainer<Enemy> enemies)
    {
       enemies.RenderEntities();
    }

    public void MoveEnemy(Enemy enemy)
    {
        enemy.Shape.Position.Y = enemy.Shape.Position.Y;
    }
}