using DIKUArcade.Entities;
using DIKUArcade.Math;

namespace Galaga.MovementStrategy;

public class ZigZagDown : IMovementStrategy
{
    public void MoveEnemies(EntityContainer<Enemy> enemies){
       enemies.RenderEntities();
    }

    public void MoveEnemy(Enemy enemy){
        float s = enemy.Speed;
        float a = 0.05f;
        float p = 0.00045f;
        double newY = enemy.Shape.Position.Y - s;
        double newX = enemy.Shape.Position.X + a * System.Math.Sin(2*System.Math.PI * (enemy.Shape.Position.Y - newY)/p); 
    }
}