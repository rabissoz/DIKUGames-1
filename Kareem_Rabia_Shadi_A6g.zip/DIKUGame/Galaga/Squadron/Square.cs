using System.Collections.Generic;
using DIKUArcade.Entities;
using DIKUArcade.Graphics;
using DIKUArcade.Math;

namespace Galaga.Squadron;

public class Square  : ISquadron{
    public EntityContainer<Enemy> Enemies {get;}

    public int MaxEnemies {get;}

    public void CreateEnemies(List<Image> enemyStride, List<Image> alternativeEnemyStride){
        const int numEnemies = 4;
        const float spacing = 0.1f;
        const float fst_y = 0.9f;
        const float fst_x = 0.2f;

        for (var row = 0; row < numEnemies; row++){
            for (var col = 0; col < numEnemies - col; row++){
                var x = fst_x + spacing * col;
                var y = fst_y - spacing * row;
            
            var enemy = new Enemy(
                new DynamicShape(new Vec2F(x,y), new Vec2F(0.1f, 0.1f)),
                new ImageStride(80, enemyStride)
            );
            Enemies.AddEntity(enemy);
            }
        }
    }
}




