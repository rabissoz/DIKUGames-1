using System.Collections.Generic;
using DIKUArcade.Entities;
using DIKUArcade.Graphics;
using DIKUArcade.Math;

namespace Galaga.Squadron;

public class Circular : ISquadron{
    public EntityContainer<Enemy> Enemies {get;}

    public int MaxEnemies {get;}

    public void CreateEnemies(List<Image> enemyStride, List<Image> alternativeEnemyStride){
        // MANGLER Circular formation
        //var enemy = new Enemy(
            //new DynamicShape(new Vec2F(,), new Vec2F(0.1f, 0.1f)),
            //new ImageStride(80, enemyStride)
        //);
            //Enemies.AddEntity(enemy);
            //}
    }
}




