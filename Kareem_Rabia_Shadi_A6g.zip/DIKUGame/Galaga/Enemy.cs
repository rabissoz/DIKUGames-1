using DIKUArcade.Entities;
using DIKUArcade.Graphics;
namespace Galaga;
public class Enemy : Entity {

    private int hp = 4;
    public int HP {
        get {return hp;}
        set {hp = value;}
    }

    private float speed = 0.0003f;
    public float Speed {
        get {return speed;}
        set {speed = value;}
    }
    public Enemy(DynamicShape shape, IBaseImage image) : base(shape, image) {
        }
    }
