Generated on http://arcade.photonstorm.com/ using the "Battle Bakraid
(Eighting)" font.
